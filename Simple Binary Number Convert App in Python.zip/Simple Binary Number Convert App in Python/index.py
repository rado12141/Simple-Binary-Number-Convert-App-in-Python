from os import system, name
def clear(): 
  
    
    if name == 'nt': 
        _ = system('cls') 
  
    
    else: 
        _ = system('clear')
clear()

print("======== Binary Number Converter App ========\n ******This app can convert a decimal to a binary or vice versa ******\n")
print("-->Choose an option\n")
print("{}{}{}".format("(1)Binary to Decimal\n","(2)Decimal to Binary\n","(3)Exit\n"))
ValSelectionM=int(input("Please select a number for operation:\n>>"))
if(ValSelectionM==1):
    exec(open('main1.py').read())
else:
    if(ValSelectionM==2):
        exec(open('main2.py').read())
    else:
        if(ValSelectionM==3):
            exit()
        else:
           
            if(ValSelectionM>3):
                print("Number not found. Please select a number from table.")
                exec(open('BinCalculator.py').read())#Restart
            else:
                if(ValSelectionM<1):
                    print("Number not found. Please select a number from table.")
                    exec(open('BinCalculator.py').read())#Restart
            
